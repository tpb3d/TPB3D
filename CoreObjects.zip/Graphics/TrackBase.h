#pragma once
/*#include "ObjectBase.h"

class TrackBase : public ObjectBase
{
public:
   TrackBase( int PointCount, int ID );
   ~TrackBase(void);
};
*/
