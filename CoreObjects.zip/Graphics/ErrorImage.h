#pragma once

#include <vector>

namespace Gfx
{
   extern unsigned char ErrorImagePixels [64*64*4+1];
}
