/*   This file is part of Extreme Park Developer.
*
*   Extreme Park Developer is free software: you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation, either version 3 of the License, or
*   (at your option) any later version.

*   Extreme Park Developer is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with Extreme Park Developer.  If not, see <http://www.gnu.org/licenses/>.
*/


#include <list>
#include <vector>
#include <iostream>
#include <cstdlib>
#include "../People/Person.h"
#include "../CoreObjects/Routes.h"
#include "../CoreObjects/PersonQueue.h"
#include "../CoreObjects/RouteBase.h"
#include "../CoreObjects/Building.h"
#include "../CoreObjects/Park.h"
#include "../Root/EPDException.h"
#include "../People/Peeps.h"
#include "RideAgent.h"

#include "PathAgent.h"
#include "PeepAgent.h"

PeepsAgent::PeepsAgent (Park& Park) // use a Park agent for multiple Parks
      :  mPark (Park)
{

}

PeepsAgent::~PeepsAgent ()
{
}

void PeepsAgent::Update (float dt, int tod)
{
   // Shouldn't Peeps be a member within each Park? Supposedly you would want this seperate.
   Peeps* Peeps = Peeps::get_Instance(); // the Peeps object that holds the people collection
   if ( (rand() % 4) == 3 )  // TODO: need a better spawn mechanism, raised to 100
   {

      //Location loc; // all zeros
      Person* peep = Peeps->NewPerson();
//      Person* peep = new Person( loc );
//      mPeople.push_back( peep );
      // Shouldn't this be Update(dt)?
      Peeps->Update( dt );
//log      std::cout << "Your city added 1 person" << " Population in city: " << Peeps->GetPopulation() << std::endl;
   }
   // std::list<Person*> Should be a member typedef!
   std::list<Person *>::iterator i;
   std::list<Person *>& persons = Peeps->get_Persons(); // get the persons collection.

   // TODO: Need to create a better interface that provides a clear persons iteration.
   for (i = persons.begin (); i != persons.end (); i++)
   {
      Person* peep = (*i);
      peep->Update( tod );
      Path& workPath = peep->get_WorkPath(); // for now just doing work
      //  TODO: case statement from hell, on the refactor list
      // use a state engine to replace this
      switch ( peep->get_Activity() )
      {
         case Person::AS_GoingHome:

            if ( workPath.index >= 0 )
            {
               int idx = workPath.index;
               int curPathway = peep->get_Location().mPathway;
               if ( curPathway == workPath.mPathList[idx].mPathway )
               {
                  // just moving on the same Pathway
               }
               else
               {
                  switch ( peep->GetCurrentState() )
                  {
                  case Person::CS_Waiting:
                     // tally up wait states
                     break;
                  case Person::CS_Riding:
                     // enroute
                     break;
                  case Person::CS_Disembarking:
                     if (workPath.index)
                     {
                        workPath.index--;
                     }
                     peep->SetCurrentState( Person::CS_Walking );
                     // fall through
                  default:
                     break;
                  }
               }
            }
            else
            {
            }
            break;
         default:
            // do something
            break;   // microsoft requires this break
      }
   }
}

void PeepsAgent::Draw()
{
   Peeps* Peeps = Peeps::get_Instance(); // the Peeps object that holds the people collection
   std::list<Person *>::iterator i;
   std::list<Person *>& persons = Peeps->get_Persons(); // get the persons collection.

   // TODO: Need to create a better interface that provides a clear persons iteration.
   for (i = persons.begin (); i != persons.end (); i++)
   {
      Person* peep = (*i);
      if( peep && peep->GetCurrentState() == Person::AS_JobHunting )
      {
         // this needs major kinemation
         peep->Draw( 320, 36); // standing outside
      }
   }
}
