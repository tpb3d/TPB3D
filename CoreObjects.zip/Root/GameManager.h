/*   This file is part of Extreme Park Developer.
 *
 *   Extreme Park Developer is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.

 *   Extreme Park Developer is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with Extreme Park Developer.  If not, see <http://www.gnu.org/licenses/>.
 */

// root of the Pathways and subPathways, the building/ Park.
// create an instance of this. The lobby is created empty.
// call newPathway or newSubPathway to add floors or basement Pathways
#ifndef _GAMEMANAGER_H
#define _GAMEMANAGER_H

class Park;
class Scene;
class TiXmlElement;
class TiXmlNode;

// Park is a ModelObject along with all the FloorSpace entities
// This renderes the Park in the ModelSpaces with perspective, pan and zoom.
class GameManager
{

private:
   Scene& mScene;
   Park& mPark;

public:
   GameManager( Scene& scene, Park& thePath);
   ~GameManager() {}
   void InitialSetup();
   bool LoadGame(const char* fileName);
   bool SaveGame(const char* fileName);

   bool LoadPark(TiXmlNode* nPark, Park* pPark);
   bool SavePark(TiXmlElement* pnParent, Park* pPark);

   void Add( TiXmlNode* pnElement, const char* szTag, const char* szText);
};

#endif //_GAMEMANAGER_H
