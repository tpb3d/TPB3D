#include <SFML/System.hpp>
#include <SFML/Graphics.hpp>
#include "CamPath.h"

// nothing here yet