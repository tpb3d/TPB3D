#pragma once

struct CamPath
{
   sf::Vector3f point;
   sf::Vector3f angle;
};
