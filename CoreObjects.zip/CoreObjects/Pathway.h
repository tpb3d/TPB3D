/*   This file is part of ExtremePark Developer.
 *
 *   ExtremePark Developer is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.

 *   ExtremePark Developer is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with ExtremePark Developer.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _Pathway_H
#define _Pathway_H
#include <map>
#include <list>

#include "../Graphics/ModelObject.h"
#include "CoreBase.h"

class AnimationSingle;
class AnimationEmpty;
class CoreBase;
class Park;
class RouteBase;
class PersonQueue;
class GameManager;
class FloorAgent;

class Pathway : public Gfx::ModelObject
{
   friend class GameManager;
   friend class FloorAgent;
private:
   std::map<unsigned int, CoreBase*> mFloorSpaces;
   Park * mParkParent;
   int  mID;

public:
   static const int mUnitSize;

protected:
   int   mPathway;
   int   mX;    // lower left origin.x
   int   mX2;   // x vector = width
   int   mY;    // lower left origin.y
               // y vector = height
   float mZ;     // face set to zero
               // z vector = depth but not implement until 3D
   AnimationSingle* nFireEscapeLeft;
   AnimationSingle* nFireEscapeRight;
   AnimationSingle* mEmptyFLoor;
   AnimationEmpty* mThePathway;

protected:
   // Pathway open Space tracking grid (proto type stuff
   // Just using allocated simple byte array for easy debugging
   unsigned char*  mpFloorSpaceGrid;
   int   mFloorSpaceGridSize;
   bool  mFloorIsFull;        // Can't place any more objects
   bool  mNoEmptyFloorSpace;  // Skip the DrawEmptySpace function
public:
   bool  IsFloorFull()
   {
      return mFloorIsFull;
   }

   // Pathway tracking methods/functions
   void  ResizeFloorSpaceGrid();
   void  ScanFloorSpace(); // Marks the gird for what is in the space
   bool  IsSpaceEmpty( int x, int x2 ); // TestForEmptySpace...
   void  DrawEmptySpace();
   void  DrawSelectionTarget (bool PathwayOnly);
   void  DrawEmptyFramework();
   // End prototype code

public:
   // CTOR
   Pathway (int Pathway, int x, int y, int x2, Park * ParkParent);
   // Initialize from an xml node
   virtual ~Pathway ();

public:
   // decls
   typedef std::map<unsigned int, CoreBase*>::iterator FloorIterType;
   typedef std::map<unsigned int, CoreBase*> FloorMap;

   // Properties
protected:
   inline FloorMap& GetFloorSpaces()
   {
      return mFloorSpaces;
   }
public:
   inline int GetPathway () { return mPathway; }
   inline int GetID () { return mID; }
   inline int GetX () { return mX; }

   // Methods
   virtual void Update (float dt, int tod);
   virtual void Draw ();

   bool AddFloorSpace (CoreBase * floor);
   void SetFloorPositions( int x, int x2 );
   CoreBase* GetSpaceByID (int id);
   CoreBase* FindSpace (int x); // location

   bool TestForEmptySpace (int x, int x2 );

   void Save(SerializerBase& ser);
};

#endif

