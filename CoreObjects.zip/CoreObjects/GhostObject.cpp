/*   This file is part of Extreme Park Developer.
 *
 *   Extreme Park Developer is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.

 *   Extreme Park Developer is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with Extreme Park Developer.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "../Graphics/Image.h"
#include "../Types/String.h"
#include "CoreBase.h"
#include "Park.h"
#include "Pathway.h"

#include "GhostObject.h"

using namespace Gfx;
//using namespace ParkObjects;

GhostObject::GhostObject (int x, int pathno)
      :  mCurrentState (GS_Invalid)
      ,  CoreBase (x, x + Pathway::mUnitSize, pathno, NULL)
      ,  mBase (Pathway::mUnitSize, 1)
{
   mWidthUnits = 1;
   mOffsetUnits = 0;
}

void GhostObject::SetState( Ghost_State gs )
{
   const float cfGreen[] = { 0.0f, 255.0f, 63.0f, 127.0f };
   const float cfGray[] = { 127.0f, 63.0f, 63.0f, 127.0f };
   mBase.SetLightingColor( (gs == GS_Valid) ? cfGreen : cfGray );
}

void GhostObject::SetWidth( int units)
{
   mWidthUnits = units;
   mOffsetUnits = units / 2;
   mBase.SetWidth ((float)(units * 1));
}

void GhostObject::Move (Vector3f& point)
{
   int x = int(point.x) - mOffsetUnits;
   int y = int(point.y);
   mX = (float)(x);
   mX2 = mX + 1;
   mY = (float)(y);
   mLevel = mY + 1;
   mZ = -0.1f; // point.z;
   mBase.SetPosition (mX, mY);
}

void GhostObject::Update (Park* pPark)
{
   SetState (GS_Invalid);
}

void GhostObject::Draw ()
{
   RenderRectangle (&mBase);
}

