//#pragma once
/*#include "stdafx.h"
#include "TrackBase.h"

TrackBase::TrackBase( int PointCount, int ID )
:  ObjectBase( PointCount, ID)
{
}

TrackBase::~TrackBase(void)
{
}
*/
