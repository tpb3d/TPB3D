//  --------------------------------------------------------------------
//  Copyright (C)2010 Ralph Daigle.   All rights reserved.
//  Licensed according to the GPL v3.0
//
//  Hub class
//
//  You should have received a copy of the GNU General Public License
//  along with Theme Park Developer 3D The Game.  If not, see <http://www.gnu.org/licenses/>.
//////////////////////////////////////////////////////////////////////

//  RideHub        Stationay Structural element such as the pylon for the yoyo and carousel.

#pragma once
#include "RideNode.h"
#include "../Graphics/ObjectBase.h"
#include "../Graphics/TexturedMesh.h"
#include "../Physics/RotationPhysics.h"

class Hub : public RideNode, public TexturedMesh, public RotationPhysics
{
   float mHeight;
   float mRadii[4];
   short mSides;
   short mSections;

public:
   Hub (float height, short sides );
   ~Hub(void);

   ObjectBase* Clone( );
   void IncreseSides();
   void DecreseSides();
   void Update(int dt);
   void Render();
   void Draw();
   void DrawSelectionTarget();

   void Load(SerializerBase& ser);
   void Save(SerializerBase& ser);
};
